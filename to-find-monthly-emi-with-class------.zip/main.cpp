#include<iostream>
#include<cmath>
using namespace std;
class EMI
{
    public:
    float p;
    float r;
    float R=r/12/100;
    float t;
    float EMI;
    void input()
    {
        cout<<"Enter the Principle value : "<<endl;
        cin>>p;
        cout<<"Enter the rate of interest : "<<endl;
        cin>>r;
        cout<<"Enter the Time duration in years : "<<endl;
        cin>>t;
        
    }
    void output()
    {
        EMI= (p*R*pow((1+R),t))/(pow((1+R),t - 1));
        cout<<"Your EMI is = "<<EMI;
        
    }
};
int main()
{
    EMI e;
    e.input();
    e.output();
}