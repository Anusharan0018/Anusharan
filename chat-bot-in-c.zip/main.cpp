#include<iostream>
using namespace std;
int main()
{
    int choice;
    cout<<" ========Alma Chatbot(C++ program)======="<<endl;
    while(1){
        cout<<"Select an optin :"<<endl;
        cout<<"Enter 1. for Course"<<endl;
        cout<<"Enter 2. for Fee"<<endl;
        cout<<"Enter 3. for Admission"<<endl;
        cout<<"Enter 4. for Locatin "<<endl;
        cout<<"Enter 5. for Contact"<<endl;
        cout<<"Enter 6. for Placements"<<endl;
        cout<<"Enter 7. for Exit"<<endl;
        cout<<"Enter yours choice :"<<endl;
        cin>>choice;
        switch(choice)
        {
            case 1:
            cout<<"Course : DCA , DIT , Web Designing , Digital Marketing , AI\n"<<endl;
            break;
            
            case 2:
            cout<<"Fee starts from Rs. 1000 per month.\n"<<endl;
            break;
            
            case 3:
            cout<<"Admission are open visit our centre or Contact us.\n"<<endl;
            break;
            
            case 4:
            cout<<"Location : Tripuri & SST Nagar,Patiala.\n"<<endl;
            break;
            
            case 5:
            cout<<"Contact : 9888330468\n"<<endl;
            break;
            
            case 6:
            cout<<"Placements : Patiala,Ludhiana,Chandigarh\n"<<endl;
            break;
            
            case 7:
            cout<<"Thankyou for using Alma Chatbot.\n"<<endl;
            return 0;
            default:
            cout<<"invalid choice . please try again .\n"<<endl;
            
        }
    }
    return 0;
}