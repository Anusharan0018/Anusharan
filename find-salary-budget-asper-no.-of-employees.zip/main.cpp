#include<iostream>
using namespace std;

int main()
{
    int n, salary, sum=0, i, amount, leftmoney,adver , tax , last , input;

abc:    cout << "Enter no. of Employees: " << endl;
    cin >> n;

    for(i=0; i<n; i++)
    {
        cout << "Enter Salary of employee " << i + 1 << ": ";
        cin >> salary;
        sum+=salary;
    }
    cout << "It is the total salary amount: " << sum << endl;
    cout << "Enter the Total Amount given: " << endl;
    cin >> amount;

    leftmoney = amount - sum;
    cout << "Here is the left amount: " << leftmoney << endl;
    cout << "Enter Advertisment amount  : "<<endl;
    cin>> adver;
    cout << " Enter tax amount : "<<endl;
    cin>> tax;
    last=leftmoney - (adver+tax);
    cout<< " It is the Amount left after tax and Advertisment are cutted :"<<last<<endl;
    cout<< " Do you want to continue then press 1 and enter , other wise press any key and enter"<<endl;
    cin>>input;
    if(input == 1)
    {
        goto abc;
        
    }
    else
    {
        cout<<"take a rest now "<<endl;
        
    }
    return 0;
    

    return 0;
}    
